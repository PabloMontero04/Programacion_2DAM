/**
 * 
 */
/**
 * 
 */
module FuncionesLambda {
	requires java.desktop;
}