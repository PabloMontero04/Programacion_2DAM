/**
 * 
 */
/**
 * 
 */
module NotaEstudiantesMaps {
	requires java.desktop;
}