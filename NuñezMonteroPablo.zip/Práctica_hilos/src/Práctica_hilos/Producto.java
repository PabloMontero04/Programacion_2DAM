	package Práctica_hilos;
	
	class Producto {
	    int tipo;
	
	    public Producto(int tipo) {
	        this.tipo = tipo;
	    }
	}
	
