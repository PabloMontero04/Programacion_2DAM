package GestionInventarioMaps;

public class Producto {
    private double precio;
    private double unidades;

    // Getters and setters
    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getUnidades() {
        return unidades;
    }

    public void setUnidades(double unidades) {
        this.unidades = unidades;
    }
}
