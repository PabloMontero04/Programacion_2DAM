/**
 * 
 */
/**
 * 
 */
module GestionInventarioMaps {
	requires java.desktop;
}