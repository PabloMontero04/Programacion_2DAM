/**
 * 
 */
/**
 * 
 */
module JuegoJodaBro {
	requires java.desktop;
}